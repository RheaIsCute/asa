﻿==============================================================================
                          HOOKLOADER (v1.0)
       SetWindowsHookEx DLL Injector with Modern Web Control UI
==============================================================================

[ OVERVIEW ]
Hookloader is a stealth DLL injector designed to load dynamic link libraries 
into target process windows (e.g. VALORANT / Unreal Engine window) using 
Windows message hooking (SetWindowsHookExW - WH_GETMESSAGE). 

It features an embedded, modern dark-themed Web Interface that automatically 
opens in your default browser on startup for seamless, easy DLL selection, 
one-click injection, and safe unhooking.

------------------------------------------------------------------------------
[ PACKAGE CONTENTS ]
------------------------------------------------------------------------------
hookloader/
  |-- hookloader.exe      -> Main Hookloader server & injector application
  |-- README.txt          -> Detailed setup and operational instructions
  |-- INSTRUCTIONS.txt    -> Quick-start guide
  \-- src/                -> Complete source code & Visual Studio project
        |-- hookloader.sln
        |-- hookloader/   -> C++ core injector source code
        \-- web_ui/       -> Modern Web GUI front-end source files

------------------------------------------------------------------------------
[ HOW TO RUN & USE ]
------------------------------------------------------------------------------
STEP 1: Start your target game or application (e.g. Valorant). Ensure the 
        game window is fully loaded.

STEP 2: Run "hookloader.exe" as Administrator:
        - Right-click "hookloader.exe" -> Select "Run as administrator".
        (Administrator rights are required to attach hooks to elevated windows)

STEP 3: The console will start the local control server and automatically 
        open the Web Interface in your default browser at:
        http://127.0.0.1:8080

STEP 4: In the Web Interface:
        - Click the file upload box or drag and drop your payload DLL.
        - Click the "Inject Hook" button.

STEP 5: Check Status:
        - The web UI and console will report injection status:
          * "Hook installed!" -> Injection successful!
          * "TARGET_NOT_FOUND" -> Target game window was not found.
          * "NO_EXPORT" -> Target DLL does not export any functions.

STEP 6: Unhooking & Clean Exit:
        - When finished, click "Unhook" in the Web UI to safely remove 
          the message hook before closing the game.
        - Close the console window to stop the server.

------------------------------------------------------------------------------
[ TROUBLESHOOTING & FAQ ]
------------------------------------------------------------------------------
Q: The browser didn't open automatically.
A: Manually navigate to http://127.0.0.1:8080 in Chrome, Edge, or Firefox.

Q: Error: "TARGET_NOT_FOUND"
A: Make sure the game/window is running and not minimized before clicking Inject.

Q: Error: "Bind failed on port 8080"
A: Another application is already using port 8080. Close that application 
   or release port 8080 and restart hookloader.exe.

Q: Antivirus triggered a detection.
A: Windows Hooking (SetWindowsHookExW) and memory manipulation are frequently 
   flagged as heuristic false-positives by antivirus software. Add an exclusion 
   if necessary.

------------------------------------------------------------------------------
[ COMPILING FROM SOURCE ]
------------------------------------------------------------------------------
Requirements:
- Visual Studio 2022 / 2026 with Desktop C++ Workload (MSVC toolset)
- Windows 10 / 11 SDK

Steps:
1. Open "src/hookloader.sln" in Visual Studio.
2. Select "Release" and "x64" configuration.
3. Build the solution (Ctrl + Shift + B).
4. The output binary will be created in the build folder.
==============================================================================
