# hookloader

Advanced DLL injection interface.

## Features
- Web UI based control
- Safe unhooking process
- Drag and drop injection

## Instructions
Run \hookloader.exe\ and navigate to http://127.0.0.1:8080
